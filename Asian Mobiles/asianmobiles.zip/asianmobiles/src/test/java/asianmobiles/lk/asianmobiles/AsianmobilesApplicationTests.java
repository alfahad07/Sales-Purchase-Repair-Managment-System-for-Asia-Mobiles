package asianmobiles.lk.asianmobiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsianmobilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
